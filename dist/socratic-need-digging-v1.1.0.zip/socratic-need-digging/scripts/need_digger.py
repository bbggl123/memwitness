#!/usr/bin/env python3
"""
需求深挖分析器 (Need Digger)
基于苏格拉底式四维度框架（强度/频率/范围/价值），从会议转录或需求文本中挖掘真需求。

两种后端：
  1. LLM 驱动（推荐）：通过 OpenAI 兼容接口做语义分析，需配置环境变量
  2. 规则引擎（降级）：无 LLM 时用关键词匹配 + 数字提取 + 规则评分，精度较低但不依赖外部服务

配置（LLM 模式）：
  export NEED_DIGGER_LLM_BASE_URL="https://api.openai.com/v1"
  export NEED_DIGGER_LLM_API_KEY="sk-xxx"
  export NEED_DIGGER_LLM_MODEL="gpt-4o-mini"

用法：
  # CLI
  python need_digger.py --input transcript.txt --format md > report.md
  python need_digger.py --text "客户说我们需要加人..." --format json
  python need_digger.py --input transcript.txt --format md --context '{"company":"某SaaS公司","industry":"金融"}'

  # 作为库
  from need_digger import NeedDigger
  digger = NeedDigger()
  result = digger.analyze("会议转录文本", context={"industry": "金融"})
  print(digger.to_json(result))
  print(digger.to_feishu_doc(result))
"""

import json
import os
import re
import argparse
import sys
from typing import Optional
from datetime import datetime


# ===========================================================================
#  LLM 后端
# ===========================================================================

class LLMBackend:
    """OpenAI 兼容 LLM 后端，负责将分析任务委托给大语言模型。"""

    def __init__(self):
        self.base_url = os.environ.get("NEED_DIGGER_LLM_BASE_URL", "")
        self.api_key = os.environ.get("NEED_DIGGER_LLM_API_KEY", "")
        self.model = os.environ.get("NEED_DIGGER_LLM_MODEL", "gpt-4o-mini")
        self.available = bool(self.base_url and self.api_key)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError:
                raise RuntimeError(
                    "LLM 模式需要 openai 库：pip install openai"
                )
            self._client = OpenAI(
                base_url=self.base_url, api_key=self.api_key
            )
        return self._client

    def chat(self, system_prompt: str, user_prompt: str,
             temperature: float = 0.3, max_tokens: int = 2000) -> str:
        """调用 LLM，返回纯文本响应。"""
        if not self.available:
            raise RuntimeError("LLM 后端未配置环境变量")
        client = self._get_client()
        resp = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content

    def chat_json(self, system_prompt: str, user_prompt: str,
                  temperature: float = 0.2) -> dict:
        """调用 LLM 并解析 JSON 响应。"""
        raw = self.chat(system_prompt, user_prompt, temperature=temperature)
        return self._extract_json(raw)

    @staticmethod
    def _extract_json(text: str) -> dict:
        """从 LLM 响应中提取 JSON（兼容 markdown 代码块包裹）。"""
        # ```json ... ``` 或 ``` ... ```
        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if match:
            return json.loads(match.group(1))
        # 裸 JSON 对象
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise ValueError(f"无法从 LLM 响应中提取 JSON: {text[:200]}")


# ===========================================================================
#  规则引擎（降级后端，无 LLM 时使用）
# ===========================================================================

class RuleEngine:
    """
    降级分析引擎：用关键词匹配 + 数字提取 + 规则评分做基础分析。
    精度远不如 LLM，但零依赖、离线可跑。
    """

    # 痛点信号词及其 (分数, 标签)
    PAIN_SIGNALS = {
        # 5分信号
        "无法": (5, "无法完成"), "不能": (5, "无法完成"), "必须": (5, "必须解决"),
        "严重": (5, "严重问题"), "影响业务": (5, "影响业务"),
        "客户流失": (5, "客户流失"), "系统崩溃": (5, "系统崩溃"), "瘫痪": (5, "业务瘫痪"),
        # 4分信号
        "经常出错": (4, "经常出错"), "人手不足": (4, "人手不足"), "人力不足": (4, "人力不足"),
        "不够用": (4, "资源不足"), "无法按时": (4, "无法按时完成"), "来不及": (4, "来不及处理"),
        "效率低": (4, "效率低下"), "耗时": (4, "耗时过长"), "成本高": (4, "成本高"),
        "压力": (4, "压力大"), "瓶颈": (4, "存在瓶颈"), "积压": (4, "任务积压"),
        # 3分信号
        "困难": (3, "存在困难"), "麻烦": (3, "操作麻烦"), "不方便": (3, "不方便"),
        "不合理": (3, "流程不合理"), "需要优化": (3, "需要优化"), "希望改进": (3, "希望改进"),
        "不满意": (3, "不满意"),
        # 2分信号
        "不太方便": (2, "不太方便"), "有点慢": (2, "有点慢"), "偶尔": (2, "偶尔出现"),
        # 1分信号
        "还好": (1, "还好"), "有时候": (1, "有时候"), "偶尔发生": (1, "偶尔发生"),
    }

    # 频率信号词
    FREQ_SIGNALS = {
        "每天": (5, "每天发生"),
        "每周": (4, "每周发生"),
        "每月": (4, "每月发生"), "每个月": (4, "每月发生"),
        "每季度": (3, "每季度发生"),
        "每半年": (2, "每半年发生"),
        "每年": (2, "每年发生"),
        "实时": (5, "实时持续"),
        "持续": (5, "持续发生"),
        "一直": (5, "持续发生"),
        "经常": (4, "经常发生"),
        "总是": (5, "总是发生"),
        "偶尔": (2, "偶尔发生"),
        "有时": (2, "有时发生"),
        "周期性": (3, "周期性发生"),
        "固定": (3, "固定时间节点"),
    }

    # 范围信号词
    SCOPE_SIGNALS = {
        "全公司": (4, "全公司范围"),
        "全集团": (5, "集团范围"),
        "所有部门": (4, "所有部门"),
        "跨部门": (4, "跨部门"),
        "全行业": (5, "全行业"),
        "多个部门": (3, "多个部门"),
        "整个团队": (3, "整个团队"),
        "部分部门": (2, "部分部门"),
        "某个部门": (2, "单个部门"),
        "个别人": (1, "个别人"),
    }

    # 价值信号词
    VALUE_SIGNALS = {
        "节省": (4, "成本节约"),
        "降低成本": (4, "降低成本"),
        "提升效率": (4, "提升效率"),
        "增加收入": (5, "增加收入"),
        "减少错误": (3, "减少错误"),
        "降低风险": (4, "降低风险"),
        "合规": (4, "合规风险降低"),
        "自动化": (4, "自动化提效"),
        "ROI": (4, "投资回报"),
    }

    # 模糊表述
    VAGUE_PATTERNS = [
        "很多", "经常", "有时", "大概", "可能", "应该", "比较",
        "很", "非常", "不少", "差不多", "基本上", "好像", "感觉",
        "相对来说", "某种程度上",
    ]

    @classmethod
    def extract_numbers(cls, text: str) -> list:
        """从文本中提取数字（含中文数字）。"""
        # 阿拉伯数字（含万/千等单位）
        numbers = []
        # 匹配 "2000份" "3个人" "50元" 等
        for m in re.finditer(r'(\d+(?:\.\d+)?)\s*(份|个|人|单|条|条|元|万|小时|分钟|天|周|月|年|次|%|%)?', text):
            num_str = m.group(1)
            unit = m.group(2) or ""
            numbers.append({"value": float(num_str), "unit": unit, "context": text[max(0, m.start()-10):m.end()+10]})
        return numbers

    @classmethod
    def score_by_signals(cls, text: str, signal_map: dict) -> tuple:
        """根据信号词评分，返回 (score, matched_evidence)。"""
        best_score = 3  # 默认中等
        evidence_parts = []
        for keyword, (score, label) in signal_map.items():
            if keyword in text:
                if score > best_score:
                    best_score = score
                idx = text.find(keyword)
                snippet = text[max(0, idx - 15):idx + len(keyword) + 15].strip()
                evidence_parts.append(f"[{label}] {snippet}")
        if not evidence_parts:
            evidence_parts.append("未检测到明确信号词，需追问确认")
        return best_score, evidence_parts

    @classmethod
    def decode_intent(cls, text: str) -> dict:
        """规则版意图解码。"""
        # 声称痛点
        pain_keywords = ["问题", "困难", "痛点", "不方便", "效率低",
                          "人手不足", "成本高", "不够用", "来不及", "积压"]
        surface_pain = "未明确识别"
        for kw in pain_keywords:
            idx = text.find(kw)
            if idx >= 0:
                surface_pain = text[max(0, idx - 30):idx + 50].strip()
                break

        # 暗示方案
        solution_keywords = ["需要", "想要", "希望", "建议", "增加",
                             "购买", "开发", "建设", "实现", "引入"]
        implied_solution = "未明确识别"
        for kw in solution_keywords:
            idx = text.find(kw)
            if idx >= 0:
                implied_solution = text[max(0, idx - 20):idx + 60].strip()
                break

        # 模糊表述
        vagueness = []
        for pattern in cls.VAGUE_PATTERNS:
            idx = text.find(pattern)
            if idx >= 0:
                vagueness.append(text[max(0, idx - 15):idx + 20].strip())
        if not vagueness:
            vagueness = ["未检测到明显模糊表述"]

        return {
            "surface_pain": surface_pain,
            "implied_solution": implied_solution,
            "vagueness_flags": vagueness[:5],
        }

    @classmethod
    def evaluate_dimensions(cls, text: str) -> dict:
        """规则版四维度评估。"""
        intensity_score, intensity_ev = cls.score_by_signals(text, cls.PAIN_SIGNALS)
        freq_score, freq_ev = cls.score_by_signals(text, cls.FREQ_SIGNALS)
        scope_score, scope_ev = cls.score_by_signals(text, cls.SCOPE_SIGNALS)
        value_score, value_ev = cls.score_by_signals(text, cls.VALUE_SIGNALS)

        numbers = cls.extract_numbers(text)
        number_evidence = ""
        if numbers:
            num_summary = ", ".join(
                f"{n['value']}{n['unit']}" for n in numbers[:5]
            )
            number_evidence = f"文本中提取到数字: {num_summary}"

        return {
            "intensity": {
                "score": intensity_score,
                "evidence": "; ".join(intensity_ev[:3]),
                "numbers_found": number_evidence,
                "questions": cls._default_questions("intensity"),
            },
            "frequency": {
                "score": freq_score,
                "evidence": "; ".join(freq_ev[:3]),
                "questions": cls._default_questions("frequency"),
            },
            "scope": {
                "score": scope_score,
                "evidence": "; ".join(scope_ev[:3]),
                "questions": cls._default_questions("scope"),
            },
            "value": {
                "score": value_score,
                "evidence": "; ".join(value_ev[:3]),
                "questions": cls._default_questions("value"),
            },
        }

    @classmethod
    def identify_gaps(cls, text: str, intent: dict) -> dict:
        """规则版 Gap 识别。"""
        gaps = []
        # 检测是否有数字支撑
        numbers = cls.extract_numbers(text)
        if not numbers:
            gaps.append({
                "type": "信息盲区",
                "explanation": "未提供任何量化数据，无法评估问题规模",
                "missing_info": "发生频率、影响人数、成本数据",
            })
        # 检测模糊表述数量
        if len(intent.get("vagueness_flags", [])) >= 3:
            gaps.append({
                "type": "信息盲区",
                "explanation": "存在多处模糊表述，关键信息缺失",
                "missing_info": "; ".join(intent["vagueness_flags"][:3]),
            })
        # 检测"加人"类方案错位（正则匹配"增加/加/招/补充...人/人员/编制/人手/人力"）
        if re.search(r'(增加|加|招|扩招|补充|增编).{0,8}(人|人员|编制|人手|人力|员工|财务)', text):
            gaps.append({
                "type": "方案错位",
                "explanation": "客户倾向于通过增加人力解决问题，可能忽略了流程/系统优化",
                "missing_info": "当前流程效率、自动化程度、瓶颈环节",
            })
        if not gaps:
            gaps.append({
                "type": "待确认",
                "explanation": "规则引擎未能识别明确 Gap，建议用 LLM 模式深度分析或人工复核",
                "missing_info": "N/A",
            })
        return {"gaps": gaps}

    @classmethod
    def generate_recommendations(cls, dims: dict, gaps: dict) -> list:
        """规则版建议生成。"""
        recs = []
        # 基于维度评分给建议
        avg_score = sum(d["score"] for d in dims.values()) / len(dims)
        if avg_score >= 4:
            recs.append("P0 优先：该需求四维度评分较高，建议立即启动需求细化")
        elif avg_score >= 3:
            recs.append("P1 近期：该需求有一定价值，建议排入近期需求池")
        else:
            recs.append("P2 排期：该需求优先级一般，建议评估 ROI 后再排期")
        # 基于 Gap 给建议
        for gap in gaps.get("gaps", []):
            if gap["type"] == "信息盲区":
                recs.append(f"追问：{gap['missing_info']}")
            elif gap["type"] == "方案错位":
                recs.append("重新定义：客户提出的方案可能不是最优解，建议探索流程/系统优化路径")
        recs.append("注意：当前为规则引擎降级分析，精度有限，建议配置 LLM 后端获取深度洞察")
        return recs

    @staticmethod
    def _default_questions(dim: str) -> list:
        """各维度默认追问清单。"""
        questions = {
            "intensity": [
                "这个问题发生的频率有多高？",
                "目前用什么方式解决？成本是多少？",
                "如果不解决，最坏后果是什么？",
            ],
            "frequency": [
                "这个需求是周期性出现还是偶发？",
                "如果系统上线，用户会每天/每周/每月使用吗？",
            ],
            "scope": [
                "这个问题影响哪些岗位/团队？",
                "是全公司范围还是某个部门？",
                "有多少用户会遇到这个问题？",
            ],
            "value": [
                "解决后能节省多少人力成本？",
                "能提升多少效率或收入？",
                "能降低什么风险？",
            ],
        }
        return questions.get(dim, [])


# ===========================================================================
#  NeedDigger 主类
# ===========================================================================

# --- LLM Prompt 模板 ---

PROMPT_SYSTEM_BASE = """你是苏格拉底式需求深挖分析师，精通 FDE（前线部署工程师）方法论。
你的任务不是记录客户说了什么，而是通过四维度框架（强度/频率/范围/价值）挖掘客户的真实需求。

核心原则：
1. 不信任表面陈述——永远追问"为什么"
2. 量化优先——能数字化的不模糊描述
3. 识别 Gap——表面需求与真需求之间的错位

四维度评分标准（1-5分）：
- 强度：1=可接受偶尔发生 / 3=困扰有替代但成本高 / 5=不可忍受无替代
- 频率：1=年度偶发 / 3=月度 / 5=每日持续
- 范围：1=个别人 / 3=多部门 / 5=全公司/全行业
- 价值：1=微弱改善 / 3=中等效率提升 / 5=核心业务影响

Gap类型：
- 方案错位：用户要A，实际需要B（如要人→要流程规范）
- 信息盲区：关键数据未提供（如不知道替代方案成本）
- 假设错误：基于错误前提（如以为人手不足是主因）
"""

PROMPT_INTENT = PROMPT_SYSTEM_BASE + """

【任务：意图解码】
分析以下文本，提取三个要素，返回 JSON：
{
  "surface_pain": "客户明确说的痛点（引用原话或概括）",
  "implied_solution": "客户暗示的解决方向（引用原话或概括）",
  "vagueness_flags": ["每个模糊/未量化的表述，附带原文片段"]
}

只返回 JSON，不要其他文字。"""

PROMPT_DIMENSIONS = PROMPT_SYSTEM_BASE + """

【任务：四维度评估】
基于以下文本，对强度、频率、范围、价值四个维度各打 1-5 分。
每个维度必须给出：
- score: 1-5 的整数评分
- evidence: 从文本中找到的支持评分的证据（引用原话或数据）
- questions: 该维度信息不足时需要追问的问题（2-3个）
- confidence: 评分置信度 high/medium/low（信息不足时标 low）

返回 JSON：
{
  "intensity": {"score": 0, "evidence": "", "questions": [], "confidence": ""},
  "frequency": {"score": 0, "evidence": "", "questions": [], "confidence": ""},
  "scope": {"score": 0, "evidence": "", "questions": [], "confidence": ""},
  "value": {"score": 0, "evidence": "", "questions": [], "confidence": ""}
}

只返回 JSON，不要其他文字。"""

PROMPT_GAP = PROMPT_SYSTEM_BASE + """

【任务：Gap 识别】
对比以下表面需求与文本内容，识别表面需求与真需求之间的错位。

返回 JSON：
{
  "gaps": [
    {
      "type": "方案错位|信息盲区|假设错误",
      "surface_need": "表面需求",
      "root_problem": "可能的真需求",
      "explanation": "为什么这是错位",
      "missing_info": "缺失的关键信息（如有）"
    }
  ],
  "root_need_summary": "一句话概括可能的真需求"
}

只返回 JSON，不要其他文字。"""

PROMPT_RECOMMENDATIONS = PROMPT_SYSTEM_BASE + """

【任务：综合建议】
基于以下分析结果，生成优先级排序的行动建议。

要求：
- 每条建议标注优先级 P0（立即）/ P1（近期）/ P2（排期）/ P3（延后）
- 建议要具体可执行，不要空话
- 包含追问清单（信息不足时需要向客户确认的问题）

返回 JSON：
{
  "recommendations": [
    {"priority": "P0", "action": "具体建议", "rationale": "为什么"}
  ],
  "follow_up_questions": ["需要向客户确认的问题"]
}

只返回 JSON，不要其他文字。"""


class NeedDigger:
    """苏格拉底式需求深挖分析器。

    自动检测 LLM 后端是否可用：
    - 可用 → LLM 驱动深度分析
    - 不可用 → 降级到规则引擎（精度低但离线可跑）
    """

    def __init__(self):
        self.llm = LLMBackend()
        self.backend = "llm" if self.llm.available else "rule"
        self.history = []

    def analyze(self, meeting_transcript: str,
                context: Optional[dict] = None) -> dict:
        """
        主分析入口。

        Args:
            meeting_transcript: 会议转录文本或客户需求描述
            context: 额外上下文（如公司背景、行业、已知信息等）

        Returns:
            结构化分析报告 dict
        """
        context = context or {}
        context_str = json.dumps(context, ensure_ascii=False) if context else "无"
        full_input = f"【上下文】\n{context_str}\n\n【待分析文本】\n{meeting_transcript}"

        if self.backend == "llm":
            intent = self._llm_decode_intent(full_input)
            dims = self._llm_evaluate_dimensions(full_input)
            gaps = self._llm_identify_gaps(full_input, intent)
            combined = {"intent": intent, "dimensions": dims, "gaps": gaps}
            recs = self._llm_generate_recommendations(combined)
        else:
            intent = RuleEngine.decode_intent(meeting_transcript)
            dims = RuleEngine.evaluate_dimensions(meeting_transcript)
            gaps = RuleEngine.identify_gaps(meeting_transcript, intent)
            recs = RuleEngine.generate_recommendations(dims, gaps)

        analysis = {
            "metadata": {
                "analyzed_at": datetime.now().isoformat(),
                "transcript_length": len(meeting_transcript),
                "backend": self.backend,
                "llm_model": self.llm.model if self.backend == "llm" else None,
                "version": "1.1.0",
            },
            "intent_decoding": intent,
            "four_dimensions": dims,
            "gap_analysis": gaps,
            "recommendations": recs,
        }

        self.history.append({
            "timestamp": datetime.now().isoformat(),
            "input_length": len(meeting_transcript),
            "backend": self.backend,
            "output": analysis,
        })

        return analysis

    # --- LLM 模式实现 ---

    def _llm_decode_intent(self, full_input: str) -> dict:
        try:
            return self.llm.chat_json(PROMPT_INTENT, full_input)
        except Exception as e:
            # LLM 调用失败，降级到规则
            text = full_input.split("【待分析文本】")[-1].strip()
            result = RuleEngine.decode_intent(text)
            result["_fallback_reason"] = str(e)
            return result

    def _llm_evaluate_dimensions(self, full_input: str) -> dict:
        try:
            return self.llm.chat_json(PROMPT_DIMENSIONS, full_input)
        except Exception as e:
            text = full_input.split("【待分析文本】")[-1].strip()
            result = RuleEngine.evaluate_dimensions(text)
            result["_fallback_reason"] = str(e)
            return result

    def _llm_identify_gaps(self, full_input: str, intent: dict) -> dict:
        gap_input = f"{full_input}\n\n【已解码的意图】\n{json.dumps(intent, ensure_ascii=False)}"
        try:
            return self.llm.chat_json(PROMPT_GAP, gap_input)
        except Exception as e:
            text = full_input.split("【待分析文本】")[-1].strip()
            result = RuleEngine.identify_gaps(text, intent)
            result["_fallback_reason"] = str(e)
            return result

    def _llm_generate_recommendations(self, combined: dict) -> list:
        rec_input = json.dumps(combined, ensure_ascii=False)
        try:
            result = self.llm.chat_json(PROMPT_RECOMMENDATIONS, rec_input)
            recs = result.get("recommendations", [])
            follow_ups = result.get("follow_up_questions", [])
            if follow_ups:
                recs.append({
                    "priority": "追问",
                    "action": "向客户确认以下问题",
                    "rationale": "; ".join(follow_ups),
                })
            return recs if recs else ["分析完成，未生成具体建议"]
        except Exception as e:
            dims = combined.get("dimensions", {})
            gaps = combined.get("gaps", {})
            recs = RuleEngine.generate_recommendations(dims, gaps)
            recs.append(f"_LLM 建议生成失败，降级到规则: {e}")
            return recs

    # --- 输出格式 ---

    def to_json(self, analysis: dict, pretty: bool = True) -> str:
        """转换为 JSON 格式字符串。"""
        return json.dumps(analysis, ensure_ascii=False,
                          indent=2 if pretty else None)

    def to_feishu_doc(self, analysis: dict) -> str:
        """转换为飞书文档 Markdown 格式。"""
        meta = analysis["metadata"]
        intent = analysis["intent_decoding"]
        dims = analysis["four_dimensions"]
        gaps = analysis["gap_analysis"]
        recs = analysis["recommendations"]

        dim_cn = {
            "intensity": "强度", "frequency": "频率",
            "scope": "范围", "value": "价值",
        }

        lines = [
            "# 需求深挖报告",
            "",
            f"**分析时间：** {meta['analyzed_at']}  ",
            f"**分析后端：** {'LLM (' + meta.get('llm_model', '?') + ')' if meta['backend'] == 'llm' else '规则引擎（降级）'}  ",
            f"**文本长度：** {meta['transcript_length']} 字符",
            "",
            "---",
            "",
            "## 一、意图解码",
            "",
            "### 表面痛点",
            f"> {intent.get('surface_pain', 'N/A')}",
            "",
            "### 暗示方案",
            f"> {intent.get('implied_solution', 'N/A')}",
            "",
            "### 模糊表述",
        ]

        for v in intent.get("vagueness_flags", []):
            lines.append(f"- {v}")
        if not intent.get("vagueness_flags"):
            lines.append("- 未检测到")

        lines.extend(["", "---", "", "## 二、四维度分析", ""])

        for dim_key in ["intensity", "frequency", "scope", "value"]:
            dim_data = dims.get(dim_key, {})
            score = dim_data.get("score", 0)
            stars = "★" * score + "☆" * (5 - score) if isinstance(score, int) else "★★★☆☆"
            cn_name = dim_cn.get(dim_key, dim_key)
            confidence = dim_data.get("confidence", "")
            conf_tag = f" `[{confidence}]`" if confidence else ""

            lines.append(f"### {cn_name} {stars}{conf_tag}")
            lines.append(f"- **评分：** {score}/5")
            lines.append(f"- **证据：** {dim_data.get('evidence', 'N/A')}")
            if dim_data.get("numbers_found"):
                lines.append(f"- **数据：** {dim_data['numbers_found']}")
            questions = dim_data.get("questions", [])
            if questions:
                lines.append("- **追问清单：**")
                for q in questions:
                    lines.append(f"  - {q}")
            lines.append("")

        # Gap 分析
        lines.extend(["---", "", "## 三、Gap 分析", ""])

        gap_list = gaps.get("gaps", [])
        if isinstance(gaps, list):
            gap_list = gaps  # 兼容直接返回 list 的情况

        root_summary = gaps.get("root_need_summary", "")
        if root_summary:
            lines.append(f"**真需求概括：** {root_summary}")
            lines.append("")

        if gap_list:
            for i, gap in enumerate(gap_list, 1):
                lines.append(f"### Gap {i}：{gap.get('type', '未知')}")
                if gap.get("surface_need"):
                    lines.append(f"- **表面需求：** {gap['surface_need']}")
                if gap.get("root_problem"):
                    lines.append(f"- **真需求：** {gap['root_problem']}")
                lines.append(f"- **说明：** {gap.get('explanation', 'N/A')}")
                if gap.get("missing_info"):
                    lines.append(f"- **缺失信息：** {gap['missing_info']}")
                lines.append("")
        else:
            lines.append("未识别到明确 Gap。")
            lines.append("")

        # 建议
        lines.extend(["---", "", "## 四、行动建议", ""])

        for rec in recs:
            if isinstance(rec, dict):
                priority = rec.get("priority", "")
                action = rec.get("action", "")
                rationale = rec.get("rationale", "")
                lines.append(f"- **[{priority}]** {action}")
                if rationale:
                    lines.append(f"  - 理由：{rationale}")
            else:
                lines.append(f"- {rec}")

        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append(
            "> 本报告由苏格拉底式需求深挖技能自动生成。"
            "评分和 Gap 仅为分析参考，最终判断需结合业务上下文。"
        )

        return "\n".join(lines)


# ===========================================================================
#  CLI 入口
# ===========================================================================

def main():
    parser = argparse.ArgumentParser(
        description="苏格拉底式需求深挖分析器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  python need_digger.py --input transcript.txt --format md
  python need_digger.py --text "客户说我们需要加人手" --format json
  python need_digger.py --input transcript.txt --format md --context '{"industry":"金融"}'

LLM 配置（可选，不配则用规则引擎降级）：
  export NEED_DIGGER_LLM_BASE_URL="https://api.openai.com/v1"
  export NEED_DIGGER_LLM_API_KEY="sk-xxx"
  export NEED_DIGGER_LLM_MODEL="gpt-4o-mini"
        """,
    )
    parser.add_argument("--input", "-i", help="输入文件路径（会议转录/需求文本）")
    parser.add_argument("--text", "-t", help="直接输入文本（与 --input 二选一）")
    parser.add_argument(
        "--format", "-f", choices=["json", "md"], default="md",
        help="输出格式：json 或 md（默认 md）",
    )
    parser.add_argument(
        "--context", "-c", help="额外上下文 JSON 字符串（如 {\"industry\":\"金融\"}）",
    )
    parser.add_argument(
        "--backend-info", action="store_true",
        help="仅输出当前后端信息后退出",
    )

    args = parser.parse_args()

    if args.backend_info:
        llm = LLMBackend()
        print(f"后端模式: {'LLM' if llm.available else '规则引擎（降级）'}")
        if llm.available:
            print(f"  Base URL: {llm.base_url}")
            print(f"  Model: {llm.model}")
        else:
            print("  （未配置 NEED_DIGGER_LLM_* 环境变量）")
        return

    # 获取输入文本
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            text = f.read()
    elif args.text:
        text = args.text
    else:
        # 从 stdin 读取
        print("请输入待分析文本（Ctrl+D 结束）：", file=sys.stderr)
        text = sys.stdin.read()

    if not text.strip():
        print("错误：输入文本为空", file=sys.stderr)
        sys.exit(1)

    # 解析上下文
    context = None
    if args.context:
        try:
            context = json.loads(args.context)
        except json.JSONDecodeError as e:
            print(f"警告：上下文 JSON 解析失败: {e}，忽略上下文", file=sys.stderr)

    # 执行分析
    digger = NeedDigger()
    print(f"[分析后端: {digger.backend}]", file=sys.stderr)
    analysis = digger.analyze(text, context=context)

    # 输出
    if args.format == "json":
        print(digger.to_json(analysis))
    else:
        print(digger.to_feishu_doc(analysis))


if __name__ == "__main__":
    main()
