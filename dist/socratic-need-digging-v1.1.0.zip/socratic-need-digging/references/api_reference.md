# API 参考：need_digger.py

`need_digger.py` 是需求深挖技能的可编程核心——把 SKILL.md 里的四维度方法论落地为可调用、可 CLI 运行的 Python 工具。

---

## 环境要求

- Python 3.8+
- 标准库即可运行（规则引擎降级模式）
- LLM 模式需额外安装 `openai` 库：`pip install openai`

---

## LLM 配置

脚本通过三个环境变量配置 OpenAI 兼容的 LLM 后端。**不配则自动降级到规则引擎**（精度低但不依赖外部服务）。

| 环境变量 | 必填 | 默认值 | 说明 |
|----------|------|--------|------|
| `NEED_DIGGER_LLM_BASE_URL` | 是（LLM模式） | 空 | OpenAI 兼容 API 地址，如 `https://api.openai.com/v1` |
| `NEED_DIGGER_LLM_API_KEY` | 是（LLM模式） | 空 | API 密钥 |
| `NEED_DIGGER_LLM_MODEL` | 否 | `gpt-4o-mini` | 模型名，建议用支持 JSON 输出的模型 |

配置示例：

```bash
export NEED_DIGGER_LLM_BASE_URL="https://api.openai.com/v1"
export NEED_DIGGER_LLM_API_KEY="sk-xxx"
export NEED_DIGGER_LLM_MODEL="gpt-4o-mini"
```

> 任何 OpenAI 兼容端点均可（如 DeepSeek、Moonshot、自部署 vLLM 等），只要支持 `/chat/completions` 接口。

---

## NeedDigger 类 API

### `NeedDigger()`

构造分析器。自动检测 LLM 环境变量是否配置，选择后端。

```python
from need_digger import NeedDigger

digger = NeedDigger()
print(digger.backend)  # "llm" 或 "rule"
```

### `analyze(meeting_transcript, context=None) -> dict`

主分析入口，执行完整四步流程（意图解码 → 四维度评估 → Gap 识别 → 建议生成）。

**参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `meeting_transcript` | `str` | 是 | 会议转录文本或客户需求描述 |
| `context` | `dict` | 否 | 额外上下文，如 `{"industry": "金融", "company": "某公司"}` |

**返回：** 完整分析报告 dict（结构见下方 JSON Schema）。

```python
result = digger.analyze(
    "客户：我们财务只有3个人，每月2000份报销单，人手不够...",
    context={"industry": "SaaS", "company_size": "500人"}
)
```

### `to_json(analysis, pretty=True) -> str`

将分析结果序列化为 JSON 字符串。

```python
print(digger.to_json(result))       # 带缩进
print(digger.to_json(result, pretty=False))  # 紧凑
```

### `to_feishu_doc(analysis) -> str`

将分析结果转换为飞书文档 Markdown 格式，可直接粘贴到飞书云文档。

```python
md = digger.to_feishu_doc(result)
# 写入飞书文档：lark-cli docs +create --content-stdin < md
```

---

## JSON 输出 Schema

```json
{
  "metadata": {
    "analyzed_at": "2026-08-17T15:12:12.362937",
    "transcript_length": 107,
    "backend": "rule",          // "llm" 或 "rule"
    "llm_model": null,           // LLM 模式下为模型名
    "version": "1.1.0"
  },
  "intent_decoding": {
    "surface_pain": "客户明确说的痛点",
    "implied_solution": "客户暗示的解决方向",
    "vagueness_flags": ["模糊表述1", "模糊表述2"]
  },
  "four_dimensions": {
    "intensity": {
      "score": 4,                // 1-5 整数
      "evidence": "支持评分的证据",
      "numbers_found": "文本中提取的数字",  // 仅规则引擎有此字段
      "questions": ["追问问题1", "追问问题2"],
      "confidence": "medium"      // 仅 LLM 模式有此字段
    },
    "frequency": { "score": 4, "evidence": "...", "questions": [...] },
    "scope": { "score": 3, "evidence": "...", "questions": [...] },
    "value": { "score": 4, "evidence": "...", "questions": [...] }
  },
  "gap_analysis": {
    "gaps": [
      {
        "type": "方案错位",      // 方案错位 | 信息盲区 | 假设错误
        "surface_need": "表面需求",
        "root_problem": "真需求",
        "explanation": "为什么错位",
        "missing_info": "缺失的关键信息"
      }
    ],
    "root_need_summary": "一句话概括真需求"   // 仅 LLM 模式有此字段
  },
  "recommendations": [
    {
      "priority": "P0",          // P0 | P1 | P2 | P3 | 追问
      "action": "具体建议",
      "rationale": "为什么"
    }
  ]
}
```

> **LLM 模式 vs 规则引擎的字段差异：**
> - LLM 模式：四维度多 `confidence` 字段、Gap 多 `root_need_summary`、建议为结构化 dict
> - 规则引擎：四维度多 `numbers_found` 字段、建议为字符串列表（带降级提示）
> - 两种模式 `metadata.backend` 值不同，下游可据此判断精度

---

## CLI 用法

### 基本调用

```bash
# 从文件读取，输出 Markdown
python need_digger.py --input transcript.txt --format md

# 直接传文本，输出 JSON
python need_digger.py --text "客户说我们需要加人手" --format json

# 从 stdin 读取
echo "会议文本..." | python need_digger.py --format md

# 带上下文
python need_digger.py --input transcript.txt --format md \
  --context '{"industry":"金融","company":"某SaaS公司"}'

# 查看当前后端
python need_digger.py --backend-info
```

### 参数说明

| 参数 | 缩写 | 说明 |
|------|------|------|
| `--input` | `-i` | 输入文件路径 |
| `--text` | `-t` | 直接输入文本（与 `--input` 二选一） |
| `--format` | `-f` | 输出格式 `json` 或 `md`（默认 `md`） |
| `--context` | `-c` | 额外上下文 JSON 字符串 |
| `--backend-info` | - | 仅显示当前后端信息后退出 |

### 输出重定向

```bash
# 保存到文件
python need_digger.py -i transcript.txt -f md > report.md
python need_digger.py -i transcript.txt -f json > report.json

# 管道到其他工具
python need_digger.py -i transcript.txt -f json | jq '.four_dimensions.intensity.score'
```

---

## 两种后端对比

| 维度 | LLM 模式 | 规则引擎（降级） |
|------|----------|------------------|
| 触发条件 | 配置了 `NEED_DIGGER_LLM_*` 环境变量 | 未配置环境变量 |
| 分析深度 | 语义理解，能识别隐含逻辑 | 关键词匹配 + 数字提取 |
| 评分精度 | 基于文本证据动态评分 | 基于信号词查表评分 |
| Gap 识别 | 能识别方案错位/信息盲区/假设错误 | 仅识别"加人"类方案错位 + 信息盲区 |
| 建议质量 | 针对性强，带优先级和理由 | 通用模板，带降级提示 |
| 依赖 | 需 `openai` 库 + 网络 | 零依赖，离线可跑 |
| 适用场景 | 正式需求分析、客户会议 | 快速预筛、离线环境、LLM 不可用时 |

**推荐：** 正式使用时配置 LLM 后端；规则引擎仅作为 fallback。

---

## LLM 降级机制

LLM 模式下，如果某步 LLM 调用失败（网络超时、API 错误等），**该步自动降级到规则引擎**，不会中断整体分析。降级的步骤会在返回结果中带 `_fallback_reason` 字段说明失败原因。

```python
result = digger.analyze("...")
# 检查是否有降级
if result["intent_decoding"].get("_fallback_reason"):
    print("意图解码降级了:", result["intent_decoding"]["_fallback_reason"])
```

---

## 集成示例

### 1. 作为 Python 库

```python
from need_digger import NeedDigger

digger = NeedDigger()
result = digger.analyze(
    meeting_transcript,
    context={"industry": "SaaS", "company_size": "500人"}
)

# 获取 JSON（给开发 agent）
json_str = digger.to_json(result)

# 获取 Markdown（给飞书文档）
md_str = digger.to_feishu_doc(result)

# 直接取评分做决策
intensity_score = result["four_dimensions"]["intensity"]["score"]
if intensity_score >= 4:
    print("高优先级需求，建议立即处理")
```

### 2. Agent 调用（subprocess）

```python
import subprocess, json

result = subprocess.run(
    ["python3", "need_digger.py", "-i", "transcript.txt", "-f", "json"],
    capture_output=True, text=True
)
analysis = json.loads(result.stdout)
```

### 3. 飞书会议旁听集成

```python
# 会议结束后调用
def on_meeting_end(transcript: str):
    digger = NeedDigger()
    analysis = digger.analyze(transcript, context={"meeting_type": "客户需求会"})
    md_report = digger.to_feishu_doc(analysis)
    # output_to_feishu_doc(md_report)  # 通过 lark-cli docs 写入飞书文档
    return analysis
```

---

## 错误处理

| 场景 | 行为 |
|------|------|
| 输入文本为空 | CLI 报错退出（exit code 1） |
| LLM 未配置 | 自动降级到规则引擎，`metadata.backend="rule"` |
| LLM 调用失败 | 该步降级到规则引擎，结果带 `_fallback_reason` |
| JSON 解析失败（LLM 返回非 JSON） | 该步降级到规则引擎 |
| `--input` 文件不存在 | Python 抛 FileNotFoundError |
| `--context` JSON 格式错误 | 警告并忽略上下文，继续分析 |

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-08-17 | 骨架版本，四维度硬编码返回3分，无 LLM 接入 |
| 1.1.0 | 2026-08-17 | 重写：接入 LLM 后端 + 规则引擎降级 + 数字提取 + 正则 Gap 识别 + CLI + 完整文档 |
