#!/usr/bin/env python3
"""memctl.py — memwitness 记忆库命令行工具（纯 Python 标准库）。

L0-L3 四层记忆：L0 原始日志（append-only）→ L1 topics → L2 areas → L3 画像。
格式与 App 端 Rust 实现（crates/fde-core/src/memory/mod.rs）严格对齐：
- L0 行格式：`- [tag] YYYY-MM-DDTHH:MM:SS.mmmZ (source) text`
- 脱敏：11 位手机号（1[3-9] 开头）前3后4；18 位身份证前6后4
- 标签仲裁优先级：decided > stated > observed > inferred；learned 不参与
"""

import argparse
import contextlib
import io
import json
import re
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

TAGS = ("stated", "observed", "inferred", "decided", "learned")
TAG_PRIORITY = {"decided": 3, "stated": 2, "observed": 1, "inferred": 0, "learned": 0}
COMPACT_THRESHOLD = 500
L3_FILES = ("SOUL.md", "IDENTITY.md", "USER.md", "MEMORY.md")

# ---------------------------------------------------------------- 脱敏

def redact(text: str) -> str:
    """隐私脱敏，规则与 Rust redact() 一致。"""
    def repl(m: "re.Match[str]") -> str:
        s = m.group(0)
        if len(s) == 11 and s[0] == "1" and "3" <= s[1] <= "9":
            return s[:3] + "****" + s[-4:]
        if len(s) == 18:
            return s[:6] + "********" + s[-4:]
        return s
    return re.sub(r"\d+", repl, text)

# ---------------------------------------------------------------- 时间

def now_ms() -> int:
    return int(time.time() * 1000)

def format_ts_ms(ts_ms: int) -> str:
    """epoch 毫秒 → YYYY-MM-DDTHH:MM:SS.mmmZ（UTC），与 Rust format_ts_ms 对齐。"""
    dt = datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{ts_ms % 1000:03d}Z"

def parse_ts_ms(ts: str) -> int:
    dt = datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)

def ts_to_date(ts_ms: int) -> str:
    return format_ts_ms(ts_ms)[:10]

# ---------------------------------------------------------------- 路径

def client_dir(root: Path, client: str | None) -> Path:
    return Path(root) / "clients" / (client if client else "_unassigned")

def list_clients(root: Path) -> list[str]:
    base = Path(root) / "clients"
    if not base.is_dir():
        return []
    return sorted(p.name for p in base.iterdir() if p.is_dir())

def log_files(root: Path, client: str | None) -> list[Path]:
    log_dir = client_dir(root, client) / "log"
    if not log_dir.is_dir():
        return []
    return sorted(log_dir.glob("????-??-??.md"))

# ---------------------------------------------------------------- L0 行

LINE_RE = re.compile(r"^- \[(\w+)\] (\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z) \(([^)]*)\) (.*)$")

def render_line(tag: str, ts_ms: int, source: str, text: str) -> str:
    return f"- [{tag}] {format_ts_ms(ts_ms)} ({source}) {text}"

def parse_line(line: str):
    """解析 L0 行 → dict；不匹配返回 None。"""
    m = LINE_RE.match(line.strip())
    if not m:
        return None
    tag, ts, source, text = m.groups()
    if tag not in TAGS:
        return None
    try:
        ts_ms = parse_ts_ms(ts)
    except ValueError:
        return None
    return {"ts_ms": ts_ms, "tag": tag, "source": source, "text": text}

def append_l0(root: Path, client: str | None, tag: str, source: str, text: str, ts_ms: int) -> str:
    """追加一条 L0 到当日日志（文件按 UTC 日期），返回写入的行。"""
    line = render_line(tag, ts_ms, source, redact(text))
    log_dir = client_dir(root, client) / "log"
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / f"{ts_to_date(ts_ms)}.md"
    header = f"# {ts_to_date(ts_ms)}\n"
    if path.exists():
        body = path.read_text(encoding="utf-8")
        if body and not body.endswith("\n"):
            body += "\n"
        body += line + "\n"
    else:
        body = header + "\n" + line + "\n"
    path.write_text(body, encoding="utf-8")
    return line

def load_entries(root: Path, client: str | None = None, want_client: bool = False):
    """读取 L0 全部条目。client=None 时读所有客户。
    返回 dict 列表：client/date/idx/ts_ms/tag/source/text。"""
    clients = [client] if client else list_clients(root)
    entries = []
    for c in clients:
        for path in log_files(root, c):
            for idx, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
                parsed = parse_line(line)
                if parsed:
                    parsed.update(client=c, date=path.stem, idx=idx)
                    entries.append(parsed)
    entries.sort(key=lambda e: (e["ts_ms"], e["date"], e["idx"]))
    if want_client:
        return entries
    for e in entries:
        e.pop("client", None)
    return entries

# ---------------------------------------------------------------- 命令：init

INIT_TEMPLATES = {
    "SOUL.md": "# SOUL — Agent 人格\n\n- 语气：专业、克制、直接\n- 价值观：客户真实利益优先，诚实不编造\n- 行为边界：敏感个人信息一律不记、不问\n",
    "IDENTITY.md": "# IDENTITY — 执行身份\n\n- 我是客户的 FDE 需求分析师（前沿部署工程师）\n- 职责：听懂客户、挖出真需求、推动可交付结论\n- 红线：不确定就说不确定；重要决策请客户确认\n",
    "USER.md": "# USER — 客户画像\n\n- 角色：待补充\n- 组织：待补充\n- 偏好：待补充\n- 知识地图：待补充\n",
    "MEMORY.md": "# MEMORY — 长期记忆摘要\n\n## 下次会话应主动引用\n- （会话 ≥1 次后填入 ≥3 条历史需求点）\n\n## 长期事实\n- 待补充\n",
}

def cmd_init(args) -> int:
    root = Path(args.root)
    (root / "clients").mkdir(parents=True, exist_ok=True)
    meta = root / "_meta.json"
    if not meta.exists():
        meta.write_text(json.dumps({"version": 1, "created": format_ts_ms(now_ms())},
                                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"记忆库已初始化：{root}")
    if args.client:
        cdir = client_dir(root, args.client)
        for sub in ("log", "topics", "areas"):
            (cdir / sub).mkdir(parents=True, exist_ok=True)
        for name, content in INIT_TEMPLATES.items():
            p = cdir / name
            if not p.exists():
                p.write_text(content, encoding="utf-8")
        print(f"客户 [{args.client}] 目录与 L3 模板已就绪：{cdir}")
    return 0

# ---------------------------------------------------------------- 命令：append

def cmd_append(args) -> int:
    if args.tag not in TAGS:
        print(f"[memctl] 非法标签 {args.tag!r}，可选：{', '.join(TAGS)}", file=sys.stderr)
        return 2
    if not args.text.strip():
        print("[memctl] --text 不能为空", file=sys.stderr)
        return 2
    ts_ms = args.ts_ms if args.ts_ms is not None else now_ms()
    line = append_l0(Path(args.root), args.client, args.tag, args.source, args.text, ts_ms)
    print(f"[memctl] 已记录 → {args.client or '_unassigned'}: {line}")
    return 0

# ---------------------------------------------------------------- 命令：search

def cmd_search(args) -> int:
    words = [w.lower() for w in args.query.split()]
    if not words:
        print("[memctl] --query 不能为空", file=sys.stderr)
        return 2
    entries = load_entries(Path(args.root), args.client, want_client=not args.client)
    hits = [e for e in entries if all(w in e["text"].lower() for w in words)]
    hits.reverse()  # recency 优先
    if args.client:
        for e in hits[: args.limit]:
            print(f"- [{e['tag']}] {format_ts_ms(e['ts_ms'])} ({e['source']}) {e['text']}")
    else:
        for e in hits[: args.limit]:
            print(f"- [{e['tag']}] {format_ts_ms(e['ts_ms'])} ({e['client']}) {e['text']}")
    print(f"[memctl] 命中 {len(hits)} 条，显示 {min(len(hits), args.limit)} 条", file=sys.stderr)
    return 0

# ---------------------------------------------------------------- 命令：context

def _read_or_empty(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip() if path.exists() else "（暂无）"

def cmd_context(args) -> int:
    root = Path(args.root)
    cdir = client_dir(root, args.client)
    print(f"=== memwitness 上下文：{args.client or '_unassigned'} ===")
    for name in ("USER.md", "MEMORY.md"):
        print(f"\n[L3 {name}]\n{_read_or_empty(cdir / name)}")

    entries = load_entries(root, args.client)
    key_points = [e for e in entries if e["tag"] in ("stated", "decided")]
    print("\n[历史需求点]（stated/decided，倒序）")
    if key_points:
        for e in reversed(key_points[-20:]):
            print(f"- [{e['tag']}] {e['date']} {e['text']}")
        if len(key_points) >= 3:
            print(">> 本轮请主动引用至少 3 条历史需求点")
    else:
        print("（暂无；这是与该客户的早期会话，专注记录）")

    recent = entries[-args.recent:]
    print(f"\n[最近动态]（最近 {len(recent)} 条 L0）")
    for e in recent:
        print(f"- [{e['tag']}] {format_ts_ms(e['ts_ms'])} ({e['source']}) {e['text']}")
    return 0

# ---------------------------------------------------------------- 命令：compact

def cmd_compact(args) -> int:
    root = Path(args.root)
    clients = [args.client] if args.client else list_clients(root)
    processed = 0
    for c in clients:
        for path in log_files(root, c):
            lines = path.read_text(encoding="utf-8").splitlines()
            data = [ln for ln in lines if ln.strip().startswith("- [")]
            if len(data) <= args.threshold:
                continue
            buckets: dict[str, list[str]] = {t: [] for t in TAGS}
            for ln in data:
                parsed = parse_line(ln)
                if parsed:
                    buckets[parsed["tag"]].append(
                        f"  - {format_ts_ms(parsed['ts_ms'])} ({parsed['source']}) {parsed['text']}")
            out = [f"<!-- 提炼底稿：请将以下条目提炼进 topics/areas 后删除本文件；L0 原文 {path.name} 保留 -->",
                   f"# {path.stem} 提炼底稿（{len(data)} 条）"]
            for tag in TAGS:
                if buckets[tag]:
                    out.append(f"\n## [{tag}] ×{len(buckets[tag])}")
                    out.extend(buckets[tag])
            dest = path.with_name(f"{path.stem}.compact.md")
            dest.write_text("\n".join(out) + "\n", encoding="utf-8")
            processed += 1
            print(f"[memctl] {c}/{path.name} {len(data)} 条 > {args.threshold} → 底稿 {dest.name}")
    print(f"[memctl] compact 完成，处理 {processed} 个日志文件" if processed
          else "[memctl] compact 完成，没有超过阈值的日志")
    return 0

# ---------------------------------------------------------------- 命令：rebuild

def cmd_rebuild(args) -> int:
    root = Path(args.root)
    clients = [args.client] if args.client else list_clients(root)
    for c in clients:
        entries = load_entries(root, c)
        if not entries:
            continue
        tdir = client_dir(root, c) / "topics"
        adir = client_dir(root, c) / "areas"
        tdir.mkdir(parents=True, exist_ok=True)
        adir.mkdir(parents=True, exist_ok=True)

        index_lines = ["# 需求点索引（rebuild 自动生成，按时间倒序）", ""]
        for e in reversed(entries):
            index_lines.append(f"- [{e['tag']}] {e['date']} {e['text']}")
        (tdir / "_index.md").write_text("\n".join(index_lines) + "\n", encoding="utf-8")

        learned = [e for e in entries if e["tag"] == "learned"]
        lessons = ["# 经验教训（[learned] 自动沉淀）", ""]
        lessons += [f"- {e['date']} {e['text']}" for e in reversed(learned)] or ["（暂无）"]
        (adir / "lessons.md").write_text("\n".join(lessons) + "\n", encoding="utf-8")
        print(f"[memctl] {c}: 重建 _index.md（{len(entries)} 条）与 lessons.md（{len(learned)} 条 learned）")
    return 0

# ---------------------------------------------------------------- 命令：redact

def cmd_redact(args) -> int:
    print(redact(args.text))
    return 0

# ---------------------------------------------------------------- 命令：selftest

def cmd_selftest(_args) -> int:
    """内置自测：格式 / 脱敏 / 往返 / 端到端。与 Rust 侧测试值对齐。"""
    checks = 0

    def ok(cond, msg):
        nonlocal checks
        assert cond, f"自测失败：{msg}"
        checks += 1

    ok(redact("联系我 13812345678 收文件") == "联系我 138****5678 收文件", "手机号脱敏")
    ok(redact("身份证 110101199003077512 号") == "身份证 110101********7512 号", "身份证脱敏")
    ok(redact("工单号 10012345678") == "工单号 10012345678", "非手机号 11 位保留")
    ok(redact("预算 300 万") == "预算 300 万", "普通数字保留")

    ok(format_ts_ms(0) == "1970-01-01T00:00:00.000Z", "epoch 0")
    ok(format_ts_ms(1_700_000_000_000) == "2023-11-14T22:13:20.000Z", "已知时间戳 1")
    ok(format_ts_ms(1_763_000_000_000) == "2025-11-13T02:13:20.000Z", "已知时间戳 2")
    ok(parse_ts_ms("2023-11-14T22:13:20.000Z") == 1_700_000_000_000, "时间往返")

    line = render_line("stated", 1_700_000_000_000, "dialogue", "客户要求按项目制结算")
    ok(line == "- [stated] 2023-11-14T22:13:20.000Z (dialogue) 客户要求按项目制结算", "行格式")
    parsed = parse_line(line)
    ok(parsed is not None and parsed["tag"] == "stated" and parsed["text"] == "客户要求按项目制结算"
       and parsed["ts_ms"] == 1_700_000_000_000, "行解析往返")
    ok(parse_line("不是一条日志") is None and parse_line("- [bad] 2023-11-14T22:13:20.000Z (x) y") is None,
       "坏行返回 None")

    # 端到端：init → append → search → context → rebuild → compact
    with tempfile.TemporaryDirectory(prefix="memctl-selftest-") as tmp:
        root = Path(tmp) / "memory"

        class A:  # 轻量 args
            def __init__(self, **kw):
                self.__dict__.update(kw)

        a = A(); a.root = str(root); a.client = "客户A"
        assert cmd_init(a) == 0
        ts = 1_700_000_000_000
        for i, (tag, text) in enumerate([
            ("stated", "报销流程每月 2000 单，联系我 13912345678"),
            ("stated", "财务每周手动核对发票"),
            ("inferred", "瓶颈疑似在审核流程"),
            ("decided", "SOW 11 月底前交付"),
            ("learned", "SOW 先行减少返工"),
        ]):
            assert cmd_append(A(root=str(root), client="客户A", tag=tag, source="dialogue",
                                text=text, ts_ms=ts + i * 1000)) == 0
        ok((client_dir(root, "客户A") / "log" / "2023-11-14.md").exists(), "日志文件按日期创建")
        raw = (client_dir(root, "客户A") / "log" / "2023-11-14.md").read_text(encoding="utf-8")
        ok(raw.startswith("# 2023-11-14\n"), "日志文件头")
        ok("139****5678" in raw and "13912345678" not in raw, "append 自动脱敏")

        s_out = io.StringIO()
        with contextlib.redirect_stdout(s_out):
            cmd_search(A(root=str(root), client="客户A", query="发票", limit=50))
        ok("财务每周手动核对发票" in s_out.getvalue(), "search 单词命中")
        and_out, and_err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(and_out), contextlib.redirect_stderr(and_err):
            cmd_search(A(root=str(root), client="客户A", query="报销 发票", limit=50))
        ok("命中 0 条" in and_err.getvalue(), "search AND 语义（无同时含两词的条目）")

        ctx = A(root=str(root), client="客户A", recent=10)
        assert cmd_context(ctx) == 0
        ok(True, "context 运行")

        r = A(root=str(root), client="客户A")
        assert cmd_rebuild(r) == 0
        idx = (client_dir(root, "客户A") / "topics" / "_index.md").read_text(encoding="utf-8")
        ok("SOW 11 月底前交付" in idx and "经验教训" not in idx, "rebuild 索引")

        cp = A(root=str(root), client="客户A", threshold=2)
        assert cmd_compact(cp) == 0
        ok((client_dir(root, "客户A") / "log" / "2023-11-14.compact.md").exists(), "超阈值生成底稿")
        ok((client_dir(root, "客户A") / "log" / "2023-11-14.md").exists(), "L0 原文保留")
        raw2 = (client_dir(root, "客户A") / "log" / "2023-11-14.md").read_text(encoding="utf-8")
        ok(len([ln for ln in raw2.splitlines() if ln.startswith("- [")]) == 5, "compact 不删 L0")

    print(f"[memctl] selftest OK（{checks} 项断言全部通过）")
    return 0

# ---------------------------------------------------------------- main

def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="memctl", description="memwitness 记忆库工具（L0-L3）")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("init", help="初始化记忆库（可选同时建客户目录）")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client")
    sp.set_defaults(func=cmd_init)

    sp = sub.add_parser("append", help="追加一条 L0（自动脱敏）")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client")
    sp.add_argument("--tag", required=True, choices=TAGS)
    sp.add_argument("--source", default="dialogue")
    sp.add_argument("--text", required=True)
    sp.add_argument("--ts-ms", type=int, default=None)
    sp.set_defaults(func=cmd_append)

    sp = sub.add_parser("search", help="关键词检索 L0（AND，recency 排序）")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client")
    sp.add_argument("--query", required=True)
    sp.add_argument("--limit", type=int, default=50)
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("context", help="会话前注入包：L3 + 历史需求点 + 最近动态")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client", required=True)
    sp.add_argument("--recent", type=int, default=10)
    sp.set_defaults(func=cmd_context)

    sp = sub.add_parser("compact", help="超阈值日志生成提炼底稿（不动 L0）")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client")
    sp.add_argument("--threshold", type=int, default=COMPACT_THRESHOLD)
    sp.set_defaults(func=cmd_compact)

    sp = sub.add_parser("rebuild", help="从 L0 重建 topics/_index.md 与 areas/lessons.md")
    sp.add_argument("--root", required=True)
    sp.add_argument("--client")
    sp.set_defaults(func=cmd_rebuild)

    sp = sub.add_parser("redact", help="单句脱敏")
    sp.add_argument("--text", required=True)
    sp.set_defaults(func=cmd_redact)

    sp = sub.add_parser("selftest", help="内置自测")
    sp.set_defaults(func=cmd_selftest)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
