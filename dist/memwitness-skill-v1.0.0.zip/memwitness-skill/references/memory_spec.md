# memwitness 记忆规范（L0-L3）

> 本规范是 `memwitness` skill 的权威格式定义。App 端 Rust 实现（`crates/fde-core/src/memory/`）与本规范对齐：行格式、脱敏规则、标签优先级完全一致。

## 1. 目录布局

```
memory/                          # 记忆库根（Git 仓库，建议 git init）
├── _meta.json                   # {"version":1,"created":"ISO时间"}（init 时生成）
├── clients/
│   └── <客户名>/                # 客户是检索主键；未归属条目进 _unassigned/
│       ├── log/
│       │   └── YYYY-MM-DD.md    # L0 原始日志（append-only，永不改写历史行）
│       ├── topics/              # L1 原子记忆卡（一卡一事）
│       │   └── _index.md        # rebuild 自动生成的需求点索引
│       ├── areas/               # L2 情景归档 / 经验教训
│       │   └── lessons.md       # rebuild 自动沉淀 [learned]
│       ├── SOUL.md              # L3：Agent 人格与行为边界
│       ├── IDENTITY.md          # L3：本技能的执行身份
│       ├── USER.md              # L3：客户画像
│       └── MEMORY.md            # L3：长期记忆摘要 + 待引用清单
└── _unassigned/                 # 未确定客户的 L0 暂存（结构同上）
```

## 2. L0 原始日志

- 文件：`log/YYYY-MM-DD.md`（UTC 日期），文件头 `# YYYY-MM-DD` + 空行。
- 每行一条原子事实，格式（与 Rust `render_day_markdown` 一致）：

```
- [stated] 2026-11-13T10:30:00.000Z (dialogue) 客户要求按项目制结算
- [decided] 2026-11-13T10:31:05.000Z (meeting:M20261113) SOW 11 月底前交付
- [learned] 2026-11-13T10:32:00.000Z (dialogue) SOW 先行能显著减少返工
```

- 字段：`tag` 五标签之一；时间为 UTC ISO8601 毫秒精度；`source` ∈ `dialogue` | `meeting:<id>` | `report:<id>`。
- **append-only**：任何情况下不修改/删除已有行；纠错 = 追加新条目（矛盾双保留）。
- App 离线场景：Rust `L0Buffer` 先写本地 WAL（JSONL，`{"seq":1,"ts_ms":...,"tag":"stated","source":"dialogue","client":"客户A","text":"..."}`），联网后按 `seq` 幂等补传；服务端按 `seq` 去重后以相同行格式落盘。

### 2.1 五标签与仲裁优先级

| 标签 | 优先级 | 含义 |
|---|---|---|
| `decided` | 3 | 双方确认的决策/承诺 |
| `stated` | 2 | 客户明确陈述（原话优先） |
| `observed` | 1 | Agent 客观观察 |
| `inferred` | 0 | Agent 推测（须可回溯） |
| `learned` | —（不仲裁） | 方法论/经验教训 |

矛盾处理：**双保留**（新旧条目都留，各带时间戳），引用时取优先级高者，同级取时间新者。

### 2.2 脱敏（F3.4 红线，写入前自动执行）

- 11 位且 `1[3-9]` 开头 → 前 3 后 4：`13812345678` → `138****5678`
- 18 位数字 → 前 6 后 4：`110101199003077512` → `110101********7512`
- 其他数字原样保留；对人敏感信息（住址/银行卡/健康等）一律不记。

## 3. L1 topics（原子记忆卡）

每张卡一个文件（`topics/2026-11-13-项目制结算.md`），模板：

```markdown
# 需求点：按项目制结算
- 首次记录：2026-11-13T10:30:00.000Z
- 标签：stated → decided（2026-11-13 拍板）
- 状态：已确认
- 客户原话：["按项目制结算，不按人天"]
- 关联：meeting:M20261113；强度4/频率5/范围3/价值4（四维评分可选）
```

`_index.md` 由 `rebuild` 生成：每行 `- YYYY-MM-DD [tag] 文本`，按时间倒序。

## 4. L2 areas（情景归档）

按主题/项目归档（如 `areas/费用管理.md`）；`areas/lessons.md` 由 `rebuild` 从 `[learned]` 条目自动沉淀。模板：

```markdown
# 主题：费用管理
- 期间：2026-11 起
- 事实：…（引用 L0 时间戳）
- 经验教训：
  - 2026-11-13 SOW 先行能显著减少返工
```

## 5. L3 五件套

| 文件 | 内容 |
|---|---|
| `SOUL.md` | Agent 人格、语气、价值观、行为边界 |
| `IDENTITY.md` | 本技能执行身份：FDE 需求分析师，职责与红线 |
| `USER.md` | 客户画像：角色、组织、偏好、知识地图 |
| `MEMORY.md` | 长期记忆摘要；**须含「下次会话应主动引用」栏 ≥3 条**（PRD 验收） |

`init` 生成带占位符的模板；每次会后由 Agent 更新并 git commit。

## 6. 压缩与重建

- **压缩阈值**：单日 log > 500 行 → `compact` 生成 `log/YYYY-MM-DD.compact.md` 底稿（五标签小节 + 待提炼提示），Agent 据此更新 topics/areas 后可删底稿；**L0 原文永不删除**。
- **重建**：`rebuild` 扫描全部 L0 → 重建 `_index.md` 与 `areas/lessons.md`；L1/L2/L3 全部丢失时可从 L0 完整恢复（可审计性的最终保证）。

## 7. 会话前注入（context 命令输出结构）

```
=== memwitness 上下文：客户A ===
[L3 画像] USER.md + MEMORY.md 全文
[历史需求点] 每行：- [tag] 日期 文本   （stated/decided，倒序，≥3 条时标记"本轮请主动引用至少 3 条"）
[最近动态] 最近 10 条 L0（全标签）
```

## 8. 与 App 端的分工

| 端 | 职责 |
|---|---|
| App（Rust `fde-core::memory`） | L0 追加缓冲、WAL 掉电保护、断网补传（seq 幂等）、脱敏 |
| qwenpaw（本 skill） | L0 落盘、L1/L2 提炼、L3 画像更新、检索注入、压缩与重建、Git 留痕 |
