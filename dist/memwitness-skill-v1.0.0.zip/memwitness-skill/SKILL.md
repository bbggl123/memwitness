---
name: memwitness
description: FDE 客户记忆引擎（L0-L3 四层，纯 Markdown + Git，可审计）。当与客户对话或开会需要记录事实、会前回忆客户历史需求与偏好、会后提炼记忆入库、或检索/压缩/重建记忆库时使用。客户第二次会话前必须先取记忆上下文，并主动引用 ≥3 个历史需求点。
---

# memwitness — 客户记忆引擎（L0-L3）

## 概述

本技能实现 OptMem/memwitness 范式的客户记忆系统：**纯 Markdown 文件 + Git 留痕**，任何记忆都可回溯到 L0 原始条目，可审计、可重建。

四层架构：

| 层 | 位置 | 内容 | 谁来写 |
|---|---|---|---|
| L0 原始日志 | `log/YYYY-MM-DD.md` | 原子事实流水（五标签） | 会话中即时追加（App 端 Rust 缓冲补传 + 本技能记录） |
| L1 原子记忆 | `topics/*.md` | 提炼后的需求点/事实卡 | 会后由 Agent 提炼 |
| L2 情景归档 | `areas/*.md` | 主题/项目级归档、经验教训 | 会后由 Agent 提炼 |
| L3 画像 | `SOUL/IDENTITY/USER/MEMORY.md` | Agent 人格 + 客户画像 | 会后由 Agent 更新 |

工具：`scripts/memctl.py`（纯标准库 CLI，见文末速查）。

---

## 何时做什么（核心工作流）

### 1. 会话/会议开始前（必做）

```bash
python3 <本skill目录>/scripts/memctl.py context --root <记忆库根> --client <客户>
```

- 输出包含：L3 身份/画像 + 该客户全部历史需求点（stated/decided，按时间倒序）+ 最近动态。
- **有历史需求点 → 本轮对话必须主动引用**。同一客户第二次会话，PRD 验收要求主动引用 ≥3 个历史需求点（如"上次您提到按项目制结算、希望 11 月底前上线 SOW、预算在 30 万以内……"）。
- 记忆库为空 → 正常开始，从本轮开始积累。

### 2. 会话/会议进行中

- **只做 L0 追加，不边聊边提炼**。客户每表达一个需求/事实/约束/决策，立即追加一条：

```bash
python3 <skill>/scripts/memctl.py append --root <记忆库根> --client <客户> \
  --tag stated --source dialogue --text "客户要求按项目制结算"
```

- `source` 取值：`dialogue`（对话模式）/ `meeting:<会议id>`（会议模式）/ `report:<报告id>`。
- 手机号/身份证由工具自动脱敏（138\*\*\*\*5678 / 110101\*\*\*\*\*\*\*\*7512）；即便如此，也**不要主动询问或记录**敏感个人信息。
- App 端（离线/蓝牙会议）由 Rust `L0Buffer` 先落 WAL，联网后按 `seq` 幂等补传到记忆库；补传条目直接以相同行格式写入当日 `log/`，**不重复记录**。

### 3. 会话/会议结束后（必做）

1. 把本次 stated/decided 条目提炼成 L1 原子记忆卡，存入 `topics/`（一卡一事，含原话引用与时间戳）。
2. 更新 `USER.md`（客户画像：角色、偏好、知识地图）与 `MEMORY.md`。
3. **`MEMORY.md` 的「下次会话应主动引用」栏必须保持 ≥3 条**（直接对应 PRD 验收）。
4. `git add -A && git commit -m "memory: <客户> <日期> 会话沉淀"`（审计留痕）。

### 4. 每日 cron（建议 02:00，用 qwenpaw cron 技能）

```bash
python3 <skill>/scripts/memctl.py compact --root <记忆库根>   # 超 500 行的日志生成提炼底稿
python3 <skill>/scripts/memctl.py rebuild --root <记忆库根>   # 从 L0 重建索引与经验沉淀
```

- compact 生成底稿后，Agent 应把底稿提炼为正式的 topics/areas 条目（底稿头部有提示注释，提炼完可删底稿）。
- L0 原文**永不删除**（append-only），这是"从 L0 可重建"的保证。

---

## 五标签体系（L0 行格式：`- [tag] ISO8601时间 (source) 文本`）

| 标签 | 含义 | 示例 |
|---|---|---|
| `stated` | 客户明确说出的需求/事实（原话优先） | 客户说报销流程每月 2000 单 |
| `observed` | Agent 的客观观察（会议里谁做了什么） | 财务总监在 14:32 打断强调预算红线 |
| `inferred` | Agent 的推测（必须能回溯到具体 L0 条目） | 疑似真正瓶颈是审核流程而非人手 |
| `decided` | 已确认的决策/承诺（双方拍板） | 决定 11 月底交付 SOW v1 |
| `learned` | 方法论/经验教训沉淀（独立通道） | SOW 先行能显著减少返工 |

**仲裁优先级：`decided` > `stated` > `observed` > `inferred`**；`learned` 不参与冲突仲裁。

## 矛盾处理：双保留 + 仲裁

同一事实出现冲突版本（如客户先说预算 50 万后改 30 万）→ **两条都保留**（各带时间戳，不覆盖、不删除），引用时取优先级高者；同级取时间新者。禁止静默改写历史条目。

## 检索规则

1. 首选 `context`（一次拿到 L3 + 需求点速览 + 最近动态）。
2. 需要找具体主题时用 `search`（多关键词 AND，按时间倒序，跨客户可选）。
3. L1/L2 文件是 Markdown，可直接用文件工具 grep/阅读。

## 隐私红线（不可逾越）

- **对人的敏感个人信息一律不记**：身份证、住址、银行卡、健康、宗教、私人关系等。
- 工具层会自动脱敏手机号/身份证号，但这不是记录它们的理由。
- 工作数据（需求、决策、会议内容、项目事实）可以记。
- 任何记忆导出/分享前，先过一遍 `redact`。

---

## memctl 命令速查

| 命令 | 作用 | 关键参数 |
|---|---|---|
| `init` | 初始化记忆库（可选同时建某客户） | `--root [--client]` |
| `append` | 追加一条 L0（自动脱敏、写当日 log） | `--root --client --tag --source --text [--ts-ms]` |
| `search` | 关键词检索 L0（AND 语义，recency 排序） | `--root [--client] --query [--limit]` |
| `context` | 会话前注入包（L3 + 需求点速览 + 最近动态） | `--root --client [--recent]` |
| `compact` | 超 500 行的日志生成 L1 提炼底稿（不改 L0） | `--root [--client] [--threshold]` |
| `rebuild` | 从 L0 重建 `topics/_index.md` 与 `areas/lessons.md` | `--root [--client]` |
| `redact` | 单句脱敏 | `--text` |
| `selftest` | 内置自测（格式/脱敏/往返/压缩/重建） | 无 |

示例：`python3 scripts/memctl.py append --root memory --client 客户A --tag decided --source meeting:M20261113 --text "SOW 11 月底前交付"`
